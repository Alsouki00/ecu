﻿using Newtonsoft.Json;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

// 1. Modell för kontakt (Contact.cs)
public class Contact
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Phone { get; set; }

    public Contact(int id, string name, string email, string phone)
    {
        Id = id;
        Name = name;
        Email = email;
        Phone = phone;
    }
}

// 2. IContactService Interface (IContactService.cs)
public interface IContactService
{
    List<Contact> GetContacts();
    void AddContact(Contact contact);
    void EditContact(Contact contact);
    void DeleteContact(int id);
    void SaveContactsToFile(string filePath);
    void LoadContactsFromFile(string filePath);
}

// 3. Kontaktservice-implementering (ContactService.cs)
public class ContactService : IContactService
{
    private List<Contact> _contacts = new List<Contact>();

    public List<Contact> GetContacts() => _contacts;

    public void AddContact(Contact contact)
    {
        _contacts.Add(contact);
    }

    public void EditContact(Contact contact)
    {
        var existingContact = _contacts.FirstOrDefault(c => c.Id == contact.Id);
        if (existingContact != null)
        {
            existingContact.Name = contact.Name;
            existingContact.Email = contact.Email;
            existingContact.Phone = contact.Phone;
        }
    }

    public void DeleteContact(int id)
    {
        var contact = _contacts.FirstOrDefault(c => c.Id == id);
        if (contact != null)
        {
            _contacts.Remove(contact);
        }
    }

    public void SaveContactsToFile(string filePath)
    {
        var json = JsonConvert.SerializeObject(_contacts, Formatting.Indented);
        File.WriteAllText(filePath, json);
    }

    public void LoadContactsFromFile(string filePath)
    {
        if (File.Exists(filePath))
        {
            var json = File.ReadAllText(filePath);
            _contacts = JsonConvert.DeserializeObject<List<Contact>>(json);
        }
    }
}

// 4. Huvudapplikationen (Program.cs)
namespace ConsoleApp
{
    class Program
    {
        public static IServiceProvider ServiceProvider { get; private set; }

        static void Main(string[] args)
        {
            // Setup Dependency Injection
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddSingleton<IContactService, ContactService>();

            ServiceProvider = serviceCollection.BuildServiceProvider();

            // Hämta tjänsten
            var contactService = ServiceProvider.GetRequiredService<IContactService>();

            // Ladda kontakter från fil vid start
            contactService.LoadContactsFromFile("contacts.json");

            while (true)
            {
                Console.Clear();
                DisplayMenu();
                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        DisplayContacts(contactService);
                        break;
                    case "2":
                        AddContact(contactService);
                        break;
                    case "3":
                        EditContact(contactService);
                        break;
                    case "4":
                        DeleteContact(contactService);
                        break;
                    case "5":
                        SaveContacts(contactService);
                        break;
                    case "6":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }

        // Display the main menu
        static void DisplayMenu()
        {
            Console.WriteLine("Contact Manager");
            Console.WriteLine("1. List all contacts");
            Console.WriteLine("2. Add a new contact");
            Console.WriteLine("3. Edit a contact");
            Console.WriteLine("4. Delete a contact");
            Console.WriteLine("5. Save contacts to file");
            Console.WriteLine("6. Exit");
            Console.Write("Enter your choice: ");
        }

        // Display contacts
        static void DisplayContacts(IContactService contactService)
        {
            var contacts = contactService.GetContacts();
            if (contacts.Count == 0)
            {
                Console.WriteLine("No contacts available.");
            }
            else
            {
                foreach (var contact in contacts)
                {
                    Console.WriteLine($"ID: {contact.Id}, Name: {contact.Name}, Email: {contact.Email}, Phone: {contact.Phone}");
                }
            }
            Console.WriteLine("Press any key to return to the menu.");
            Console.ReadKey();
        }

        // Add a new contact
        static void AddContact(IContactService contactService)
        {
            Console.Write("Enter name: ");
            var name = Console.ReadLine();
            Console.Write("Enter email: ");
            var email = Console.ReadLine();
            Console.Write("Enter phone: ");
            var phone = Console.ReadLine();

            var newContact = new Contact(contactService.GetContacts().Count + 1, name, email, phone);
            contactService.AddContact(newContact);

            Console.WriteLine("Contact added successfully!");
            Console.WriteLine("Press any key to return to the menu.");
            Console.ReadKey();
        }

        // Edit a contact
        static void EditContact(IContactService contactService)
        {
            Console.Write("Enter the ID of the contact you want to edit: ");
            int id;
            if (int.TryParse(Console.ReadLine(), out id))
            {
                var contact = contactService.GetContacts().Find(c => c.Id == id);
                if (contact != null)
                {
                    Console.WriteLine($"Editing contact: {contact.Name}");
                    Console.Write("Enter new name: ");
                    contact.Name = Console.ReadLine();
                    Console.Write("Enter new email: ");
                    contact.Email = Console.ReadLine();
                    Console.Write("Enter new phone: ");
                    contact.Phone = Console.ReadLine();

                    contactService.EditContact(contact);
                    Console.WriteLine("Contact updated successfully!");
                }
                else
                {
                    Console.WriteLine("Contact not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid ID.");
            }

            Console.WriteLine("Press any key to return to the menu.");
            Console.ReadKey();
        }

        // Delete a contact
        static void DeleteContact(IContactService contactService)
        {
            Console.Write("Enter the ID of the contact you want to delete: ");
            int id;
            if (int.TryParse(Console.ReadLine(), out id))
            {
                var contact = contactService.GetContacts().Find(c => c.Id == id);
                if (contact != null)
                {
                    contactService.DeleteContact(id);
                    Console.WriteLine("Contact deleted successfully!");
                }
                else
                {
                    Console.WriteLine("Contact not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid ID.");
            }

            Console.WriteLine("Press any key to return to the menu.");
            Console.ReadKey();
        }

        // Save contacts to file
        static void SaveContacts(IContactService contactService)
        {
            contactService.SaveContactsToFile("contacts.json");
            Console.WriteLine("Contacts saved to file.");
            Console.WriteLine("Press any key to return to the menu.");
            Console.ReadKey();
        }
    }
}
