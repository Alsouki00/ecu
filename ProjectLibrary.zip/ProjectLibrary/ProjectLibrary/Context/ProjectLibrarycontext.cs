﻿
using Microsoft.EntityFrameworkCore;
using ProjectLibrary.Entitys;

namespace ProjectLibrary.Context;

public class ProjectLibrarycontext(DbContextOptions<ProjectLibrarycontext> options) : DbContext(options)
{
    public DbSet<CostumerEntety> costumers { get; set; }
    public DbSet<ProductEntity> products { get; set; }  
    public DbSet<StatusTypeEtentity> statustypes { get; set; }
    public DbSet<userEntity> users { get; set; }

}
