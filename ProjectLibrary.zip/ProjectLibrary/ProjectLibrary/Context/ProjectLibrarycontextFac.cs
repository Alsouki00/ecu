﻿using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore;

namespace ProjectLibrary.Context;

public class ProjectLibrarycontextFac : IDesignTimeDbContextFactory<ProjectLibrarycontext>
{
    public ProjectLibrarycontext CreateDbContext(string[] args)
    {
        var optionsBuilder = new DbContextOptionsBuilder<ProjectLibrarycontext>();
        optionsBuilder.UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\moham\\source\\repos\\ProjectLibrary\\ProjectLibrary\\Databases\\Local_databases.mdf;Integrated Security=True;Connect Timeout=30");

        return new ProjectLibrarycontext(optionsBuilder.Options);
    }
}