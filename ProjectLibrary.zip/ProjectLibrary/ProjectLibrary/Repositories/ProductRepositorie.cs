﻿
using ProjectLibrary.Context;

namespace ProjectLibrary.Repositories;

public class ProductRepositorie(ProjectLibrarycontext context)
{

    private readonly ProjectLibrarycontext _context = context;

}

