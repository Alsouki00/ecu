﻿
using ProjectLibrary.Context;

namespace ProjectLibrary.Repositories;

public class StatusTypeRepositorie(ProjectLibrarycontext context)
{
    private readonly ProjectLibrarycontext _context = context;

}

