﻿
using ProjectLibrary.Context;

namespace ProjectLibrary.Repositories;

public class CostumerRepositorie(ProjectLibrarycontext context)
{
    private readonly ProjectLibrarycontext _context = context;
}

