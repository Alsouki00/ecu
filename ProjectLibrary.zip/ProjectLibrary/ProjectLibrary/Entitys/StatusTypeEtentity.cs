﻿using System.ComponentModel.DataAnnotations;

namespace ProjectLibrary.Entitys;

public class StatusTypeEtentity
{
    [Key]
    public int id { get; set; }
    public string StatusName { get; set; } = null!;

}

