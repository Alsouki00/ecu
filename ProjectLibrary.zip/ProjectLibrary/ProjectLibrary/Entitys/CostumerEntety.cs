﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProjectLibrary.Entitys;

public class CostumerEntety
{
    [Key]
    public int id { get; set; }
    public string CutomerName { get; set; } = null!;
    public string Email { get; internal set; }
}
public class ProjectEntety
{
    [Key]
    public int id { get; set; }
    public string Titel { get; set; } = null!;
    public string? Description { get; set;}
    
    [Column(TypeName = "date")]
    public DateTime StartDate { get; set; }
    
    [Column(TypeName = "date")]
    public DateTime EndDate { get; set; }

    public int CostomerdID { get; set; }
    public CostumerEntety Costomer { get; set; } = null!;

    public int StatusId { get; set; }
    public StatusTypeEtentity Status { get; set; } = null!;
    
    public int UserId { get; set; }
    public userEntity User { get; set; } = null!;
    
    public int ProductId { get; set; }
    public ProductEntity Product { get; set; } = null!;

}
