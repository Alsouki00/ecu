﻿using System.ComponentModel.DataAnnotations;

namespace ProjectLibrary.Entitys;

public class ProductEntity
{
    [Key]
    public int id { get; set; }
    public string ProductName { get; set; } = null!;
    public decimal Price { get; set; }  

}
