﻿using MattinLasseiGroupApp.Data.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MattinLasseiGroupApp.Services
{
    public interface IProjectService
    {
        Task<IEnumerable<Project>> GetAllProjectsAsync();
        Task<Project> GetProjectByNumberAsync(string projectNumber);
        Task AddProjectAsync(Project project);
        Task UpdateProjectAsync(Project project);
        Task DeleteProjectAsync(string projectNumber);
    }
}