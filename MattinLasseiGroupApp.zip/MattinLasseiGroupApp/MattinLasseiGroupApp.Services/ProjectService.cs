﻿using MattinLasseiGroupApp.Data.Entities;
using MattinLasseiGroupApp.Repositories;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MattinLasseiGroupApp.Services
{
    public class ProjectService : IProjectService
    {
        private readonly IProjectRepository _projectRepository;

        public ProjectService(IProjectRepository projectRepository)
        {
            _projectRepository = projectRepository;
        }

        public async Task<IEnumerable<Project>> GetAllProjectsAsync()
        {
            return await _projectRepository.GetAllProjectsAsync();
        }

        public async Task<Project> GetProjectByNumberAsync(string projectNumber)
        {
            return await _projectRepository.GetProjectByNumberAsync(projectNumber);
        }

        public async Task AddProjectAsync(Project project)
        {
            project.ProjectNumber = GenerateProjectNumber();
            await _projectRepository.AddProjectAsync(project);
        }

        public async Task UpdateProjectAsync(Project project)
        {
            await _projectRepository.UpdateProjectAsync(project);
        }

        public async Task DeleteProjectAsync(string projectNumber)
        {
            await _projectRepository.DeleteProjectAsync(projectNumber);
        }

        private string GenerateProjectNumber()
        {
            return $"P-{DateTime.Now:yyyyMMddHHmmss}";
        }
    }
}