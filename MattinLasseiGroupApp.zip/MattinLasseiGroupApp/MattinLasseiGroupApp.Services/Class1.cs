﻿namespace MattinLasseiGroupApp.Services
{
    public class Class1
    {

    }
}
