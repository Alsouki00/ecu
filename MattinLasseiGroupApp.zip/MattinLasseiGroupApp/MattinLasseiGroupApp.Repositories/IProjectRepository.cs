﻿using MattinLasseiGroupApp.Data.Entities;

namespace MattinLasseiGroupApp.Repositories
{
    public interface IProjectRepository
    {
        Task<IEnumerable<Project>> GetAllProjectsAsync();
        Task<Project> GetProjectByNumberAsync(string projectNumber);
        Task AddProjectAsync(Project project);
        Task UpdateProjectAsync(Project project);
        Task DeleteProjectAsync(string projectNumber);
    }
}