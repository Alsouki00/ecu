﻿namespace MattinLasseiGroupApp.Repositories
{
    public class Class1
    {

    }
}
