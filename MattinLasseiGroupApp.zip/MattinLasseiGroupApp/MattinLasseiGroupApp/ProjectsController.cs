﻿using Microsoft.AspNetCore.Mvc;
using MattinLasseiGroupApp.Services;
using MattinLasseiGroupApp.Data.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MattinLasseiGroupApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectsController : ControllerBase
    {
        private readonly IProjectService _projectService;

        public ProjectsController(IProjectService projectService)
        {
            _projectService = projectService;
        }

        // GET: api/Projects
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Project>>> GetAllProjects()
        {
            var projects = await _projectService.GetAllProjectsAsync();
            return Ok(projects);
        }

        // GET: api/Projects/P-12345
        [HttpGet("{projectNumber}")]
        public async Task<ActionResult<Project>> GetProjectByNumber(string projectNumber)
        {
            var project = await _projectService.GetProjectByNumberAsync(projectNumber);
            if (project == null)
            {
                return NotFound();
            }
            return Ok(project);
        }

        // POST: api/Projects
        [HttpPost]
        public async Task<ActionResult<Project>> AddProject([FromBody] Project project)
        {
            await _projectService.AddProjectAsync(project);
            return CreatedAtAction(nameof(GetProjectByNumber), new { projectNumber = project.ProjectNumber }, project);
        }

        // PUT: api/Projects/P-12345
        [HttpPut("{projectNumber}")]
        public async Task<IActionResult> UpdateProject(string projectNumber, [FromBody] Project project)
        {
            if (projectNumber != project.ProjectNumber)
            {
                return BadRequest();
            }

            await _projectService.UpdateProjectAsync(project);
            return NoContent();
        }

        // DELETE: api/Projects/P-12345
        [HttpDelete("{projectNumber}")]
        public async Task<IActionResult> DeleteProject(string projectNumber)
        {
            await _projectService.DeleteProjectAsync(projectNumber);
            return NoContent();
        }
    }
}