﻿using Microsoft.EntityFrameworkCore;
using MattinLasseiGroupApp.Data.Entities;

namespace MattinLasseiGroupApp.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Project> Projects { get; set; }
        public DbSet<Customer> Customers { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Project>().HasKey(p => p.ProjectNumber);
            modelBuilder.Entity<Customer>().HasKey(c => c.CustomerId);
        }
    }
}