﻿namespace MattinLasseiGroupApp.Data.Entities
{
    public class Project
    {
        public string ProjectNumber { get; set; } // Automatiskt genererat
        public string Name { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string ProjectManager { get; set; }
        public string Customer { get; set; }
        public string Service { get; set; }
        public decimal TotalPrice { get; set; }
        public ProjectStatus Status { get; set; } // Enum: NotStarted, Ongoing, Completed
    }

    public enum ProjectStatus
    {
        NotStarted,
        Ongoing,
        Completed
    }
}